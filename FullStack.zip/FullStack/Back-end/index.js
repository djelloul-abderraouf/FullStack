const express =require("express");
const app = express();
require('dotenv').config();
const api = process.env.API_URL;
const bodyParser = require('body-parser');
const morgan = require('morgan');
const mongoose = require('mongoose');
const cors = require('cors');

//app.use(cors());
//app.options('*', cors());
//middleware

app.use(bodyParser.json());
app.use(morgan('tiny'));



//routes
const categoriesRoutes= require('./routes/categories');
const productsRoutes= require('./routes/products');
const usersRoutes= require('./routes/users');
const ordersRoutes= require('./routes/orders');




app.use('/api/v1/categories' , categoriesRoutes);
app.use('/api/v1/products' , productsRoutes);
app.use('/api/v1/users' , usersRoutes);
app.use('/api/v1/orders' , ordersRoutes);




//connetion a la base de donees

mongoose.connect('mongodb+srv://abderraouf:arwaeau.@cluster0.ylb97oj.mongodb.net/FullStack?retryWrites=true&w=majority')
.then(()=>{
    console.log('database connecion is ready')
} )
.catch((err)=> {
    console.log(err);
})











// specification du port

app.listen(3000, () => {
    
    console.log("server is running http://localhost:3000");
});